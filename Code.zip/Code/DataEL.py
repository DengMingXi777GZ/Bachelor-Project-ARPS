import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 假设你的文件是txt格式（你可以根据实际情况修改分隔符）
file_path = 'EL1.xlsx'  # 替换为你的文件路径

# 读取txt文件
data = pd.read_excel(file_path, header=None)

# 提取x轴数据（B4到AJ4）
x = data.iloc[3, 1:].values  # 第四行（即B4到AJ4）的数据

# 提取y轴数据（A6到A959）
y = data.iloc[5:, 0].values  # 从第六行开始，第1列的数据作为y轴（波长）

# 提取z轴数据（B6到AJ959）
z = data.iloc[5:, 1:].values  # 从第六行开始，B列到AJ列的数据作为z轴
print(z)
z = np.nan_to_num(z)  # 将NaN替换为0或其他合适的值
z = z.astype(float)  # 强制转换为 float 类型
# 绘制热力图
plt.figure(figsize=(10, 6))
plt.imshow(z, aspect='auto', cmap='viridis', origin='lower', extent=[x.min(), x.max(), y.min(), y.max()])
plt.colorbar(label='Light Intensity')  # 显示颜色条
plt.xlabel('Angle (X Axis)')
plt.ylabel('Wavelength (Y Axis)')
plt.title('Heatmap of Light Intensity Distribution')
plt.tight_layout()
plt.show()
