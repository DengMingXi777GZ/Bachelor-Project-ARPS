import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from glob import glob
import re
from scipy.interpolate import interp1d

# 参数设置
data_folder = r'Experiment\Final-film429' 

pos1_pattern = os.path.join(data_folder, 'SuperYellow-P-2degree-3_ID2-2_Data1D*.txt')
pos2_pattern = os.path.join(data_folder, 'SuperYellow-P-2degree-3_ID2-2_Data1D*.txt')
pos3_pattern = os.path.join(data_folder, 'SuperYellow-P-2degree-3_ID2-2_Data1D*.txt')

pos1_files = sorted(glob(pos1_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))
pos2_files = sorted(glob(pos2_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))
pos3_files = sorted(glob(pos3_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))

# 忽略每组的前2个和最后1个文件（保留索引2到-2的文件）
pos1_files = pos1_files[2:-1] if len(pos1_files) > 3 else pos1_files
pos2_files = pos2_files[2:-1] if len(pos2_files) > 3 else pos2_files
pos3_files = pos3_files[2:-1] if len(pos3_files) > 3 else pos3_files

angles = np.arange(-80, 81, 2)
print("Correct angles:", angles)

wavelengths = None
pos1_matrix = []
pos2_matrix = []
pos3_matrix = []

filter_range = (470, 800)  # nm

# 处理position1数据
for file in pos1_files:
    data = np.loadtxt(file, skiprows=3)
    wl = data[:, 0]
    intensity = data[:, 1]
    intensity[intensity < 0] = 0
    
    filter_mask = (wl <= filter_range[0]) | (wl >= filter_range[1])
    intensity[filter_mask] = 0
    
    if wavelengths is None:
        wavelengths = wl
    pos1_matrix.append(intensity)

# 处理position2数据
for file in pos2_files:
    data = np.loadtxt(file, skiprows=3)
    wl = data[:, 0]
    intensity = data[:, 1]
    intensity[intensity < 0] = 0
    
    filter_mask = (wl <= filter_range[0]) | (wl >= filter_range[1])
    intensity[filter_mask] = 0
    
    pos2_matrix.append(intensity)

# 处理position3数据
for file in pos3_files:
    data = np.loadtxt(file, skiprows=3)
    wl = data[:, 0]
    intensity = data[:, 1]
    intensity[intensity < 0] = 0
    
    filter_mask = (wl <= filter_range[0]) | (wl >= filter_range[1])
    intensity[filter_mask] = 0
    
    pos3_matrix.append(intensity)

# 加载校正函数
correction_data = np.loadtxt(r'Code\correction_function1.txt', delimiter='\t')
correction_func = interp1d(correction_data[:,0], correction_data[:,1], bounds_error=False, fill_value=1.0)

# 定义校正应用函数
def correct_spectral_data(wl_array, data_matrix):
    factors = correction_func(wl_array)
    return data_matrix * factors[:, np.newaxis]

#print("Wavelengths dtype:", wavelengths.dtype)
print("Wavelengths:", wavelengths)

# 应用校正并转置
pos1_matrix = correct_spectral_data(wavelengths, np.array(pos1_matrix).T)
pos2_matrix = correct_spectral_data(wavelengths, np.array(pos2_matrix).T)
pos3_matrix = correct_spectral_data(wavelengths, np.array(pos3_matrix).T)

# pos1_matrix = np.array(pos1_matrix).T
# pos2_matrix = np.array(pos2_matrix).T
# pos3_matrix = np.array(pos3_matrix).T

# 读取时间数据
time_file = os.path.join(data_folder, 'SuperYellow-P-2degree-3_ID2-2.txt')
df_time = pd.read_csv(time_file, skiprows=5, delim_whitespace=True, 
                header=None, parse_dates=[1])
#不读最后一行
df_time = df_time[:-1]
timestamps = pd.to_datetime(df_time.iloc[:, 1])
time_seconds = (timestamps - timestamps[0]).dt.total_seconds().astype(float)
print("Time in seconds:", time_seconds)

# 读取光漂白曲线（直接读地址）
bleaching_file = r'Photobleaching\bleaching_curve.xlsx'  # 替换为光漂白曲线文件的实际路径
df_bleaching = pd.read_excel(bleaching_file)
bleaching_time = df_bleaching.iloc[:, 0].values
bleaching_factor = df_bleaching.iloc[:, 2].values

# 插值光漂白曲线
bleaching_func = interp1d(bleaching_time, bleaching_factor, bounds_error=False, fill_value="extrapolate")

# 检查 time_seconds 中哪些值超出了 bleaching_time 的范围
below_bounds = time_seconds < bleaching_time.min()
above_bounds = time_seconds > bleaching_time.max()

# 找出超出范围的时间值
out_of_bounds_times = time_seconds[below_bounds | above_bounds]

if len(out_of_bounds_times) > 0:
    print("Time values out of bounds:", out_of_bounds_times)
    print("Indices of out-of-bounds times:", np.where(below_bounds | above_bounds))
else:
    print("All time values are within the bleaching time range.")

# 初始化校正因子数组
correction_factor = np.zeros_like(time_seconds)

# 第一个时间值的校正因子设置为 1.0
correction_factor[0] = 1.0

# 从第二个时间值开始进行插值
correction_factor[1:] = bleaching_func(time_seconds[1:])

# 根据光漂白曲线进行数据纠正（对每个角度内所有波长的光强进行纠正）

# 每个漂白因子 t * 0.004
correction_factor += time_seconds * 0.008
print("Correction factor:", correction_factor)
# 查看因子是否是 NumPy 数组
print("Correction factor type:", type(correction_factor))
#将纠正因子转换为 NumPy 数组
correction_factor = np.array(correction_factor)
#将数组变成(2048,33),一列中的x相同，目前的33分配成33列
correction_factor = np.tile(correction_factor, (2048, 1))
print("Correction factor shape:", correction_factor.shape)
# 应用漂白纠正
# 保存原始数据用于对比
pos1_matrix_o = pos1_matrix
pos2_matrix_o = pos2_matrix
pos3_matrix_o = pos3_matrix

# 将校正因子广播到每个角度的每个波长(点乘)
pos1_matrix *= correction_factor
pos2_matrix *= correction_factor
pos3_matrix *= correction_factor

# 计算每个位置的总光强
pos1_total = np.sum(pos1_matrix, axis=0)
pos2_total = np.sum(pos2_matrix, axis=0)
pos3_total = np.sum(pos3_matrix, axis=0)

# 归一化处理
pos1_norm_o = np.sum(pos1_matrix_o, axis=0) / np.sum(pos1_matrix_o, axis=0).max()
pos2_norm_o = np.sum(pos2_matrix_o, axis=0) / np.sum(pos2_matrix_o, axis=0).max()
pos3_norm_o = np.sum(pos3_matrix_o, axis=0) / np.sum(pos3_matrix_o, axis=0).max()
pos1_norm = pos1_total / pos1_total.max()
pos2_norm = pos2_total / pos2_total.max()
pos3_norm = pos3_total / pos3_total.max()

# 热力图数据归一化
pos1_matrix = pos1_matrix / pos1_matrix.max()
pos2_matrix = pos2_matrix / pos2_matrix.max()
pos3_matrix = pos3_matrix / pos3_matrix.max()

# 创建子图布局
fig, axes = plt.subplots(3, 2, figsize=(12, 9), gridspec_kw={'height_ratios': [3, 3, 3], 'hspace': 0.4, 'wspace': 0.3})

extent = [angles.min(), angles.max(), wavelengths[0], wavelengths[-1]]

# Position1热力图
im1 = axes[0, 0].imshow(pos1_matrix, aspect='auto', cmap='plasma', extent=extent, origin='lower', vmin=0, vmax=1)
axes[0, 0].set_ylabel('Wavelength (nm)')
axes[0, 0].set_xlabel('Angle (degrees)')
axes[0, 0].set_title('Position1 (Filtered {}-{}nm)'.format(*filter_range))
#axes[0, 0].set_ylim(400, 700)  
#axes[0, 0].set_xlim(-75, 75)
fig.colorbar(im1, ax=axes[0, 0], label='Intensity')

# Position2热力图
im2 = axes[1, 0].imshow(pos2_matrix, aspect='auto', cmap='plasma', extent=extent, origin='lower', vmin=0, vmax=1)
axes[1, 0].set_ylabel('Wavelength (nm)')
axes[1, 0].set_xlabel('Angle (degrees)')
axes[1, 0].set_title('Position2 (Filtered {}-{}nm)'.format(*filter_range))
axes[1, 0].set_ylim(400, 700)  
#axes[1, 0].set_xlim(-75, 75)  
fig.colorbar(im2, ax=axes[1, 0], label='Intensity')

# Position3热力图
im3 = axes[2, 0].imshow(pos3_matrix, aspect='auto', cmap='plasma', extent=extent, origin='lower', vmin=0, vmax=1)
axes[2, 0].set_ylabel('Wavelength (nm)')
axes[2, 0].set_xlabel('Angle (degrees)')
axes[2, 0].set_title('Position3 (Filtered {}-{}nm)'.format(*filter_range))
axes[2, 0].set_ylim(400, 700)  
#axes[2, 0].set_xlim(-75, 75)
fig.colorbar(im3, ax=axes[2, 0], label='Intensity')

# 合并第二列的子图用于对比图
gs = axes[0, 1].get_gridspec()
for ax in [axes[0, 1], axes[1, 1], axes[2, 1]]:
    ax.remove()
ax_bottom = fig.add_subplot(gs[:, 1])  # 创建一个横跨三行的新子图

# 对比图
ax_bottom.plot(angles, pos3_norm_o, label='Position1 After Correction', marker='o', color='red')
#ax_bottom.plot(angles, pos2_norm_o, label='Position2 Before Correction', marker='s', color='orange')
#ax_bottom.plot(angles, pos3_norm_o, label='Position3 Before Correction', marker='^', color='green')
#ax_bottom.plot(angles, pos1_norm, label='Position1 After Correction', marker='o', color='crimson')
ax_bottom.plot(angles, pos2_norm, label='Position2 After Correction', marker='s', color='royalblue')
ax_bottom.plot(angles, pos3_norm, label='Position3 After Correction', marker='^', color='limegreen')
ax_bottom.set_xlabel('Angle (degrees)')
ax_bottom.set_ylabel('Normalized Intensity')
ax_bottom.set_title('SuperYellow-Ion-P')
ax_bottom.legend()
ax_bottom.grid(True)
ax_bottom.set_ylim(0, 1.05)
plt.tight_layout()
plt.show()

# 提取第一个角度的光强数据
import numpy as np

# 获取所有负角度（-80到-2度）
negative_angles = [a for a in angles if a < 0]
positive_angles = np.unique(np.abs(negative_angles))  # 对应的正角度 [2,4,...,80]

# 对每个对称角度对求平均
for pos_angle in positive_angles:
    neg_angle = -pos_angle
    # 获取对应角度的索引
    neg_idx = np.where(angles == neg_angle)[0][0]
    pos_idx = np.where(angles == pos_angle)[0][0]
    
    # 计算平均值并赋给正角度
    avg_intensity = (pos1_matrix[:, neg_idx] + pos1_matrix[:, pos_idx]) / 2
    pos1_matrix[:, pos_idx] = avg_intensity

# 提取0-80度数据
start_index = np.where(angles == 0)[0][0]
end_index = np.where(angles == 80)[0][0]
selected_angles = angles[start_index:end_index + 1]  # 0到80度
selected_intensity = pos1_matrix[:, start_index:end_index + 1]

# 创建导出的数据数组
export_data = []
for i, angle in enumerate(selected_angles):
    angle_data = np.column_stack((np.full_like(wavelengths, angle),
                                wavelengths,
                                selected_intensity[:, i]))
    export_data.append(angle_data)

export_data = np.vstack(export_data)

# 保存为txt文件
output_file = r"Code\curve51_calidata_0_to_80_symmetric_avg.txt"
header = "# Angle (deg)\t# Wavelength (nm)\t# Intensity"
np.savetxt(output_file, export_data,
           fmt=["%.2f", "%.2f", "%.10e"],
           delimiter="\t",
           header=header,
           comments="")  # 去掉header前的#号
print(f"Data exported to {output_file}")






