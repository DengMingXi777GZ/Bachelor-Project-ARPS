import os
import numpy as np
import matplotlib.pyplot as plt
from glob import glob
import re

data_folder = 'Final-film' 
p_pattern = os.path.join(data_folder, 'SuperYellow-P-2degree_ID2-2_Data1D_*.txt')
s_pattern = os.path.join(data_folder, 'SuperYellow-P-2degree_ID2-2_Data1D_*.txt')

p_files = sorted(glob(p_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))
s_files = sorted(glob(s_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))

def extract_angle(filename):
    match = re.search(r'_(\d+)\.txt$', os.path.basename(filename))
    return int(match.group(1)) if match else -1

angles = [extract_angle(f) for f in p_files]
print(angles)

wavelengths = None
p_matrix = []
s_matrix = []

# 定义滤波范围
filter_range = (390, 420)  # nm

for file in p_files:
    data = np.loadtxt(file, skiprows=3)
    wl = data[:, 0]
    intensity = data[:, 1]
    intensity[intensity < 0] = 0
    
    # 应用滤波
    filter_mask = (wl >= filter_range[0]) & (wl <= filter_range[1])
    intensity[filter_mask] = 0
    
    if wavelengths is None:
        wavelengths = wl
    p_matrix.append(intensity)

for file in s_files:
    data = np.loadtxt(file, skiprows=3)
    wl = data[:, 0]
    intensity = data[:, 1]
    intensity[intensity < 0] = 0
    
    # 应用滤波
    filter_mask = (wl >= filter_range[0]) & (wl <= filter_range[1])
    intensity[filter_mask] = 0
    
    s_matrix.append(intensity)

p_matrix = np.array(p_matrix).T
s_matrix = np.array(s_matrix).T

# 归一化处理
p_total = np.sum(p_matrix, axis=0)
s_total = np.sum(s_matrix, axis=0)
max_total = max(p_total.max(), s_total.max())

p_norm = p_total / max_total
s_norm = s_total / max_total

# 创建2行2列的子图布局，但第二行只使用一个合并的子图
fig, axes = plt.subplots(2, 2, figsize=(10, 8), 
                        gridspec_kw={'height_ratios': [3, 2], 'width_ratios': [1, 1],
                                   'hspace': 0.4, 'wspace': 0.3})

# 合并第二行的两个子图
gs = axes[1, 0].get_gridspec()
for ax in axes[1, :]:
    ax.remove()  # 移除第二行原有的两个子图
ax_bottom = fig.add_subplot(gs[1, :])  # 创建一个横跨两列的新子图

extent = [min(angles), max(angles), wavelengths[0], wavelengths[-1]]

# P光热力图 - 左上 (axes[0,0])
im1 = axes[0, 0].imshow(p_matrix, aspect='auto', cmap='viridis', extent=extent, origin='lower')
axes[0, 0].set_ylabel('Wavelength (nm)')
axes[0, 0].set_title(f'P-Polarized Light (Filtered {filter_range[0]}-{filter_range[1]}nm)')
# 控制y轴范围
axes[0, 0].set_ylim(400, 700)  
fig.colorbar(im1, ax=axes[0, 0], label='P Intensity')

# S光热力图 - 右上 (axes[0,1])
im2 = axes[0, 1].imshow(s_matrix, aspect='auto', cmap='plasma', extent=extent, origin='lower')
axes[0, 1].set_ylabel('Wavelength (nm)')
axes[0, 1].set_title(f'S-Polarized Light (Filtered {filter_range[0]}-{filter_range[1]}nm)')
fig.colorbar(im2, ax=axes[0, 1], label='S Intensity')

# 总光强对比图 - 底部横跨两列 (ax_bottom)
ax_bottom.plot(angles, p_norm, label='P-Polarized', marker='o', color='crimson')
ax_bottom.plot(angles, s_norm, label='S-Polarized', marker='s', color='royalblue')
ax_bottom.set_xlabel('Angle (degrees)')
ax_bottom.set_ylabel('Normalized Total Intensity')
ax_bottom.set_ylim(0, 1.05)
ax_bottom.grid(True)
ax_bottom.legend()

plt.tight_layout()
plt.show()