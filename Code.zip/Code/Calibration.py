import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d

# 加载原始数据
file1 = pd.read_excel(r'mingxi\200-950 UV 19ms 100times.xlsx')  
file3 = pd.read_excel(r'mingxi\mingxi-200ms 20times.xlsx')  

x1, y1 = file1.iloc[:, 0].values, file1.iloc[:, 1].values
x3, y3 = file3.iloc[:, 0].values, file3.iloc[:, 1].values

# 计算校正函数 (y1/y3)
y3_interp = np.interp(x1, x3, y3)  # 将Data3插值到Data1的波长网格上
# x<200或x>800时设为1
correction_factor = np.where((x1 < 200) | (x1 > 800), 1.0, y1 / y3_interp)

# 创建校正函数对象 (便于后续使用)
correction_func = interp1d(x1, correction_factor, 
                          kind='linear', 
                          bounds_error=False, 
                          fill_value=1.0)  # 超出范围设为1

# 保存校正函数到文件
correction_data = np.column_stack((x1, correction_factor))
np.savetxt('correction_function.txt', correction_data, 
           header='Wavelength(nm)\tCorrectionFactor', 
           delimiter='\t', fmt='%.4f')

# 可视化校正函数
plt.figure(figsize=(10, 5))
plt.plot(x1, correction_factor, label='Correction Factor (y1/y3)')
plt.axvline(x=200, color='r', linestyle='--', label='Cutoff at 200nm')
plt.xlabel('Wavelength (nm)')
plt.ylabel('Correction Factor')
plt.title('Spectral Correction Function')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()