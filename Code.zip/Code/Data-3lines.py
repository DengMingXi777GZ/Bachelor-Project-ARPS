import os
import numpy as np
import matplotlib.pyplot as plt
from glob import glob
import re
from scipy.interpolate import interp1d

data_folder = 'Final-film-450' 

pos1_pattern = os.path.join(data_folder, 'SuperYellow-450-P-5degree-1_ID2-2_Data1D*.txt')
pos2_pattern = os.path.join(data_folder, 'SuperYellow-450-P-5degree-2_ID2-2_Data1D*.txt')
pos3_pattern = os.path.join(data_folder, 'SuperYellow-450-P-5degree-3_ID2-2_Data1D*.txt')

pos1_files = sorted(glob(pos1_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))
pos2_files = sorted(glob(pos2_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))
pos3_files = sorted(glob(pos3_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))

# 忽略每组的前2个和最后1个文件（保留索引2到-2的文件）
pos1_files = pos1_files[2:-1] if len(pos1_files) > 3 else pos1_files
pos2_files = pos2_files[2:-1] if len(pos2_files) > 3 else pos2_files
pos3_files = pos3_files[2:-1] if len(pos3_files) > 3 else pos3_files

angles = np.arange(-80, 81, 5)
print("Correct angles:", angles)

wavelengths = None
pos1_matrix = []
pos2_matrix = []
pos3_matrix = []

filter_range = (390, 430)  # nm

# 处理position1数据
for file in pos1_files:
    data = np.loadtxt(file, skiprows=3)
    wl = data[:, 0]
    intensity = data[:, 1]
    intensity[intensity < 0] = 0
    
    filter_mask = (wl >= filter_range[0]) & (wl <= filter_range[1])
    intensity[filter_mask] = 0
    
    if wavelengths is None:
        wavelengths = wl
    pos1_matrix.append(intensity)

# 处理position2数据
for file in pos2_files:
    data = np.loadtxt(file, skiprows=3)
    wl = data[:, 0]
    intensity = data[:, 1]
    intensity[intensity < 0] = 0
    
    filter_mask = (wl >= filter_range[0]) & (wl <= filter_range[1])
    intensity[filter_mask] = 0
    
    pos2_matrix.append(intensity)

# 处理position3数据
for file in pos3_files:
    data = np.loadtxt(file, skiprows=3)
    wl = data[:, 0]
    intensity = data[:, 1]
    intensity[intensity < 0] = 0
    
    filter_mask = (wl >= filter_range[0]) & (wl <= filter_range[1])
    intensity[filter_mask] = 0
    
    pos3_matrix.append(intensity)

# 加载校正函数
correction_data = np.loadtxt('correction_function1.txt', delimiter='\t')
correction_func = interp1d(correction_data[:,0], correction_data[:,1], bounds_error=False, fill_value=1.0)

# 定义校正应用函数
def correct_spectral_data(wl_array, data_matrix):
    factors = correction_func(wl_array)
    return data_matrix * factors[:, np.newaxis]

# 应用校正并转置
pos1_matrix = correct_spectral_data(wavelengths, np.array(pos1_matrix).T)
pos2_matrix = correct_spectral_data(wavelengths, np.array(pos2_matrix).T)
pos3_matrix = correct_spectral_data(wavelengths, np.array(pos3_matrix).T)

# pos1_matrix = np.array(pos1_matrix).T
# pos2_matrix = np.array(pos2_matrix).T
# pos3_matrix = np.array(pos3_matrix).T

# 0°对应的角度索引
zero_degree_index = 18  # 0°在angles数组中的索引

# 提取0°对应的列
zero_degree_intensity_pos1 = pos1_matrix[:, zero_degree_index]
zero_degree_intensity_pos2 = pos2_matrix[:, zero_degree_index]
zero_degree_intensity_pos3 = pos3_matrix[:, zero_degree_index]

# 找到0°列中的最大光强及其对应的波长
max_intensity_pos1 = np.max(zero_degree_intensity_pos1)
max_intensity_pos2 = np.max(zero_degree_intensity_pos2)
max_intensity_pos3 = np.max(zero_degree_intensity_pos3)

max_wavelength_pos1 = wavelengths[np.argmax(zero_degree_intensity_pos1)]
max_wavelength_pos2 = wavelengths[np.argmax(zero_degree_intensity_pos2)]
max_wavelength_pos3 = wavelengths[np.argmax(zero_degree_intensity_pos3)]

# 打印结果
print("Position1 max intensity at 0°: {:.2f}, wavelength: {:.2f} nm".format(max_intensity_pos1, max_wavelength_pos1))
print("Position2 max intensity at 0°: {:.2f}, wavelength: {:.2f} nm".format(max_intensity_pos2, max_wavelength_pos2))
print("Position3 max intensity at 0°: {:.2f}, wavelength: {:.2f} nm".format(max_intensity_pos3, max_wavelength_pos3))




# 归一化处理
pos1_total = np.sum(pos1_matrix, axis=0)
pos2_total = np.sum(pos2_matrix, axis=0)
pos3_total = np.sum(pos3_matrix, axis=0)

pos1_norm = pos1_total / pos1_total.max()
pos2_norm = pos2_total / pos2_total.max()
pos3_norm = pos3_total / pos3_total.max()

# 热力图数据归一化
#我想知道0度的最高光强






pos1_matrix = pos1_matrix / pos1_matrix.max()
pos2_matrix = pos2_matrix / pos2_matrix.max()
pos3_matrix = pos3_matrix / pos3_matrix.max()


# 打印最大值的角度和波长
max_pos1 = np.unravel_index(np.argmax(pos1_matrix), pos1_matrix.shape)
max_pos2 = np.unravel_index(np.argmax(pos2_matrix), pos2_matrix.shape)
max_pos3 = np.unravel_index(np.argmax(pos3_matrix), pos3_matrix.shape)

# 正确访问角度和波长
angle_index_pos1 = max_pos1[1]  # 列索引对应角度
wavelength_index_pos1 = max_pos1[0]  # 行索引对应波长

angle_index_pos2 = max_pos2[1]
wavelength_index_pos2 = max_pos2[0]

angle_index_pos3 = max_pos3[1]
wavelength_index_pos3 = max_pos3[0]

print("Position1 max value at angle: {}, wavelength: {}".format(angles[angle_index_pos1], wavelengths[wavelength_index_pos1]))
print("Position2 max value at angle: {}, wavelength: {}".format(angles[angle_index_pos2], wavelengths[wavelength_index_pos2]))
print("Position3 max value at angle: {}, wavelength: {}".format(angles[angle_index_pos3], wavelengths[wavelength_index_pos3]))


# 创建子图布局
fig, axes = plt.subplots(3, 2, figsize=(12, 9), gridspec_kw={'height_ratios': [3, 3, 3], 'hspace': 0.4, 'wspace': 0.3})

extent = [angles.min(), angles.max(), wavelengths[0], wavelengths[-1]]

# Position1热力图
im1 = axes[0, 0].imshow(pos1_matrix, aspect='auto', cmap='plasma', extent=extent, origin='lower', vmin=0, vmax=1)
axes[0, 0].set_ylabel('Wavelength (nm)')
axes[0, 0].set_xlabel('Angle (degrees)')
axes[0, 0].set_title('Position1 (Filtered {}-{}nm)'.format(*filter_range))
axes[0, 0].set_ylim(400, 700)  
#axes[0, 0].set_xlim(-75, 75)
fig.colorbar(im1, ax=axes[0, 0], label='Intensity')

# Position2热力图
im2 = axes[1, 0].imshow(pos2_matrix, aspect='auto', cmap='plasma', extent=extent, origin='lower', vmin=0, vmax=1)
axes[1, 0].set_ylabel('Wavelength (nm)')
axes[1, 0].set_xlabel('Angle (degrees)')
axes[1, 0].set_title('Position2 (Filtered {}-{}nm)'.format(*filter_range))
axes[1, 0].set_ylim(400, 700)  
#axes[1, 0].set_xlim(-75, 75)  
fig.colorbar(im2, ax=axes[1, 0], label='Intensity')

# Position3热力图
im3 = axes[2, 0].imshow(pos3_matrix, aspect='auto', cmap='plasma', extent=extent, origin='lower', vmin=0, vmax=1)
axes[2, 0].set_ylabel('Wavelength (nm)')
axes[2, 0].set_xlabel('Angle (degrees)')
axes[2, 0].set_title('Position3 (Filtered {}-{}nm)'.format(*filter_range))
axes[2, 0].set_ylim(400, 700)  
#axes[2, 0].set_xlim(-75, 75)
fig.colorbar(im3, ax=axes[2, 0], label='Intensity')

# 合并第二列的子图用于对比图
gs = axes[0, 1].get_gridspec()
for ax in [axes[0, 1], axes[1, 1], axes[2, 1]]:
    ax.remove()
ax_bottom = fig.add_subplot(gs[:, 1])

# 对比图
ax_bottom.plot(angles, pos1_norm, label='Position1', marker='o', color='crimson')
#ax_bottom.plot(angles, pos2_norm, label='Position2', marker='s', color='royalblue')
#ax_bottom.plot(angles, pos3_norm, label='Position3', marker='^', color='green')
ax_bottom.set_xlabel('Angle (degrees)')
ax_bottom.set_ylabel('Normalized Total Intensity')
ax_bottom.set_ylim(0, 1.05)
ax_bottom.grid(True)
ax_bottom.legend()

plt.tight_layout()
plt.show()