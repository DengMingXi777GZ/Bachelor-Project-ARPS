import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import griddata

# 假设你的文件名为"FittingDataInput429-nocali-smoothed_data.txt"
file_name = r"Code\FittingDataInput429-nocali-smoothed_data.txt"

# 初始化列表来存储数据
angles = []
wavelengths = []
intensities = []

# 读取文件
with open(file_name, "r") as file:
    for line in file:
        # 去掉每行的首尾空白字符，并按空格分割数据
        data = line.strip().split()
        if len(data) == 3:  # 确保每行有3个数据
            angle = abs(float(data[0]))  # 取角度的绝对值
            wavelength = float(data[1])
            intensity = max(float(data[2]), 0)  # 将小于0的强度值设置为0
            angles.append(angle)
            wavelengths.append(wavelength)
            intensities.append(intensity)

# 将列表转换为numpy数组以便于处理
angles = np.array(angles)
wavelengths = np.array(wavelengths)
intensities = np.array(intensities)

# 创建网格点
grid_x, grid_y = np.mgrid[np.min(angles):np.max(angles):100j, np.min(wavelengths):np.max(wavelengths):100j]

# 使用griddata进行插值
grid_z = griddata((angles, wavelengths), intensities, (grid_x, grid_y), method='cubic')

# 绘制热力图
plt.figure(figsize=(10, 6))
plt.imshow(grid_z.T, extent=[np.min(angles), np.max(angles), np.min(wavelengths), np.max(wavelengths)], 
           origin='lower', cmap='hot', aspect='auto')  # 使用热力图表示插值结果
plt.colorbar(label='Smoothed Intensity')  # 添加颜色条
plt.xlabel('Angle (degrees)')  # x轴为角度
plt.ylabel('Wavelength (nm)')  # y轴为波长
plt.title('Heatmap of Angle vs Wavelength with Smoothed Intensity')
plt.grid(True)
plt.show()