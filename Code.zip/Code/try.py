import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1. 读取数据文件
file_path = r'Code\data-SY-P-2degree-3.txt'  # 替换为你的实际文件路径
data = pd.read_csv(
    file_path,
    sep='\t',
    header=0,  # 使用第一行作为列名
    dtype={
        'angle': float,
        'wavelength': float,
        'intensity': float
    }
)

# 2. 数据预处理
# 确保没有NaN值
data = data.dropna()
# 确保强度为非负
data['intensity'] = data['intensity'].clip(lower=0)

# 3. 创建透视表
pivot_data = data.pivot_table(
    index='wavelength',
    columns='angle',
    values='intensity',
    aggfunc='mean'  # 如果有重复数据点则取平均
)
#光强归一化



# 设置容差范围
angle_tolerance = 1.0  # 角度允许±1度
wl_tolerance = 5.0     # 波长允许±5nm

# 查找同时满足两个条件的数据点
close_points = data[
    (np.abs(data['angle'] - 0) <= angle_tolerance) & 
    (np.abs(data['wavelength'] - 600) <= wl_tolerance)
]

if not close_points.empty:
    # 找出其中最接近的数据点（欧式距离最小）
    close_points['distance'] = np.sqrt(
        (close_points['angle'] - 0)**2 + 
        ((close_points['wavelength'] - 600)/100)**2  # 波长差异权重降低
    )
    closest_point = close_points.nsmallest(1, 'distance')
    
    print(f"找到{len(close_points)}个接近点，最近的点：")
    print(f"角度：{closest_point['angle'].values[0]:.2f}度")
    print(f"波长：{closest_point['wavelength'].values[0]:.2f}nm") 
    print(f"光强：{closest_point['intensity'].values[0]:.4E}")
else:
    print(f"在0±{angle_tolerance}度和600±{wl_tolerance}nm范围内未找到数据点")
    print("建议扩大容差范围或检查数据")


# 4. 数据可视化
plt.figure(figsize=(10, 6))

# 创建热力图
im = plt.imshow(
    pivot_data.values,
    aspect='auto',
    cmap='viridis',
    extent=[
        data['angle'].min(), data['angle'].max(),  # x轴范围 (角度)
        data['wavelength'].min(), data['wavelength'].max()  # y轴范围 (波长)
    ],
    origin='lower'
)

# 添加颜色条
cbar = plt.colorbar(im)
cbar.set_label('Intensity')

# 设置坐标轴标签
plt.xlabel('Angle (degrees)')
plt.ylabel('Wavelength (nm)')
plt.title('Intensity Distribution')

# 优化显示
plt.tight_layout()
plt.show()