import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import griddata

# =============================================
# Author: MingXi Deng
# Date: 2025.05.01
# Description: This script processes experimental and simulation data,get the figure
# =============================================

# =============================================
# Data Processing Functions
# =============================================

def load_and_process_experimental_data(filepath):
    """Load and process experimental data with angle shifting"""
    # Read experimental data
    data = pd.read_csv(filepath, sep="\t", comment="#", 
                      header=None, 
                      names=["angles (deg)", "Wavelengths", "intensity"])
    
    # Group by angle and sum intensities
    grouped_data = data.groupby("angles (deg)")["intensity"].sum().reset_index()
    grouped_data["angles (deg)"] = grouped_data["angles (deg)"].abs()
    
    # Normalize intensity
    grouped_data["Normalized Intensity"] = grouped_data["intensity"] / grouped_data["intensity"].max()
    
    # Apply 2-degree angle shift
    shifted_data = grouped_data.copy()
    shifted_data["angles (deg)"] = shifted_data["angles (deg)"] + 2
    
    # Add new 0-degree point (1.02x original 0-degree intensity)
    original_0deg = grouped_data[grouped_data["angles (deg)"] == 0]["Normalized Intensity"].values[0]
    new_0deg_row = pd.DataFrame({
        "angles (deg)": [0],
        "intensity": [original_0deg * grouped_data["intensity"].max()],
        "Normalized Intensity": [original_0deg]
    })
    
    # Combine and clean data
    shifted_data = pd.concat([new_0deg_row, shifted_data]).sort_values("angles (deg)").reset_index(drop=True)
    shifted_data = shifted_data[(shifted_data["angles (deg)"] >= 0) & (shifted_data["angles (deg)"] != 82)]
    
    return shifted_data

def load_simulation_data(filepath):
    """Load and process simulation data"""
    data = pd.read_csv(filepath, sep="\t", comment="#",
                      header=None,
                      names=["Emission angle (deg)", "Rad", "Rad.s", "Rad.p"])
    data["Normalized Intensity"] = data["Rad.p"] / data["Rad.p"].max()
    return data

def calculate_intensity_difference(exp_data, sim_data, metric='mae'):
    """
    Calculate difference between experimental and simulation data.
    
    Parameters:
        exp_data: Experimental data DataFrame
        sim_data: Simulation data DataFrame
        metric: 'mse' for Mean Squared Error or 'mae' for Mean Absolute Error
    
    Returns:
        Calculated error metric
    """
    squared_errors = []
    absolute_errors = []
    
    for angle in exp_data["angles (deg)"]:
        if angle in sim_data["Emission angle (deg)"].values:
            sim_value = sim_data.loc[sim_data["Emission angle (deg)"] == angle, "Rad.p"].values[0]
            exp_value = exp_data.loc[exp_data["angles (deg)"] == angle, "Normalized Intensity"].values[0]
            
            squared_errors.append((sim_value - exp_value)**2)
            absolute_errors.append(abs(sim_value - exp_value))
    
    if metric.lower() == 'mse':
        error = np.mean(squared_errors)
        print(f"MSE: {error:.6f}")
    elif metric.lower() == 'mae':
        error = np.mean(absolute_errors)
        print(f"MAE: {error:.6f}")
    else:
        raise ValueError("Invalid metric. Choose 'mse' or 'mae'")
    
    return error

# =============================================
# Plotting Functions
# =============================================

def plot_heatmap(ax, angles, wavelengths, intensities):
    """Create heatmap from experimental data"""
    # Create grid for interpolation
    grid_x, grid_y = np.mgrid[
        np.min(angles):np.max(angles):500j,
        np.min(wavelengths):np.max(wavelengths):500j
    ]
    
    # Perform cubic interpolation
    grid_z = griddata((angles, wavelengths), intensities, (grid_x, grid_y), method='cubic')
    
    # Plot heatmap
    im = ax.imshow(grid_z.T, 
                  extent=[np.min(angles), np.max(angles), np.min(wavelengths), np.max(wavelengths)],
                  origin='lower', cmap='viridis', aspect='auto')
    
    # Configure colorbar
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_ticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
    cbar.set_ticklabels(['0', '0.2', '0.4', '0.6', '0.8', '1'])
    
    # Set plot properties
    ax.set_xlabel('Angle (degrees)')
    ax.set_ylabel('Wavelength (nm)')
    ax.set_ylim(450, 800)
    ax.set_title('Experimental Emission Intensity')

def plot_comparison(ax, exp_data, sim_data):
    """Plot comparison between experimental and simulation data"""
    ax.plot(exp_data["angles (deg)"], exp_data["Normalized Intensity"],
            marker="o", linestyle="-", color="blue", label="Experiment")
    ax.plot(sim_data["Emission angle (deg)"], sim_data["Normalized Intensity"],
            marker="s", linestyle="--", color="red", label="Simulation")
    
    ax.set_title('Experiment vs Simulation Comparison')
    ax.set_xlabel('Angle (degrees)')
    ax.set_ylabel('Normalized Intensity')
    ax.legend()
    ax.grid(True)

def plot_simulation_heatmap(ax, filepath):
    """Plot simulation data as heatmap"""
    data = pd.read_csv(filepath, sep="\t", comment="#",
                      header=None,
                      names=["Wavelength (nm)", "Emission angle (deg)", "Intensity"])
    
    # Pivot and normalize data
    pivot_data = data.pivot(index="Wavelength (nm)", columns="Emission angle (deg)", values="Intensity")
    pivot_data = pivot_data / pivot_data.max().max()
    
    # Plot heatmap
    extent = [
        pivot_data.columns.min(), pivot_data.columns.max(),
        pivot_data.index.min(), pivot_data.index.max()
    ]
    
    im = ax.imshow(pivot_data, aspect='auto', cmap='viridis',
                  extent=extent, origin='lower',
                  vmin=0, vmax=pivot_data.max().max())
    
    # Configure plot
    ax.set_title('Simulation Emission Intensity')
    ax.set_xlabel('Angle (degrees)')
    ax.set_ylabel('Wavelength (nm)')
    ax.set_ylim(450, 800)
    fig.colorbar(im, ax=ax, label='Intensity')

# =============================================
# Main Execution
# =============================================

if __name__ == "__main__":
    # Load and process data
    exp_data = load_and_process_experimental_data(r"Code\FittingDataInput51-0-80-cali-smoothed_data.txt")
    sim_data1 = load_simulation_data(r"SimulationData\thick104nmOri0.03Total.txt")
    
    # Calculate intensity differences
    calculate_intensity_difference(exp_data, sim_data1)
    
    # Prepare experimental data for heatmap
    angles, wavelengths, intensities = [], [], []
    with open(r"Code\FittingDataInput51-0-80-cali-smoothed_data.txt", "r") as f:
        for line in f:
            data = line.strip().split()
            if len(data) == 3:
                angles.append(abs(float(data[0])))
                wavelengths.append(float(data[1]))
                intensities.append(max(float(data[2]), 0))
    
    angles = np.array(angles)
    wavelengths = np.array(wavelengths)
    intensities = np.array(intensities) / np.max(intensities)
    
    # Create figure
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(18, 6))
    
    # Generate plots
    plot_heatmap(ax1, angles, wavelengths, intensities)
    plot_comparison(ax2, exp_data, sim_data1)
    plot_simulation_heatmap(ax3, r"Code\Thickness103Orien0.03Emission.txt")
    
    plt.tight_layout()
    plt.show()