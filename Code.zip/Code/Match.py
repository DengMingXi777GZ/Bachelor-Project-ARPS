import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# 1. 读取Excel文件
file_path = r'photobleaching_data.xlsx'  # 替换为你的Excel文件路径
df = pd.read_excel(file_path)
X = df.iloc[:, 0].values.reshape(-1, 1)  # 第一列为特征X
y = df.iloc[:, 1].values  # 第二列为目标变量y

# 2. 数据预处理
# 检查是否有缺失值，并进行处理
# df.dropna(inplace=True)

# 3. 数据分割
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 4. 选择模型
model = RandomForestRegressor(random_state=42)

# 5. 超参数调优
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 10, 20, 30],
    'min_samples_split': [2, 5, 10]
}
grid_search = GridSearchCV(model, param_grid=param_grid, cv=5, scoring='neg_mean_squared_error', n_jobs=-1)
grid_search.fit(X_train, y_train)

# 6. 预测
y_pred = grid_search.predict(X_test)

# 7. 评估模型
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Best parameters: {grid_search.best_params_}")
print(f"Mean Squared Error: {mse}")
print(f"R^2 Score: {r2}")

# 8. 可视化结果
plt.scatter(X_train, y_train, color='blue', label='Training data')
plt.scatter(X_test, y_test, color='green', label='Test data')
plt.plot(X_test, y_pred, color='red', linewidth=2, label='Random Forest')

# 生成连续的特征值
X_continuous = np.linspace(X.min(), X.max(), 300).reshape(-1, 1)
y_continuous_pred = grid_search.predict(X_continuous)

# 创建DataFrame并保存为Excel文件
df_fit = pd.DataFrame({
    'Feature': X_continuous.ravel(),
    'Target': y_continuous_pred
})
df_fit.to_excel('fitted_curve.xlsx', index=False)

plt.xlabel('Time (seconds)')
plt.ylabel('Intensity (I/I₀)')
plt.title('Random Forest Regression')
plt.legend()
plt.show()