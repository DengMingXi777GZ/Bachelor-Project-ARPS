pos1_matrix = np.array(pos1_matrix).T
pos2_matrix = np.array(pos2_matrix).T
pos3_matrix = np.array(pos3_matrix).T