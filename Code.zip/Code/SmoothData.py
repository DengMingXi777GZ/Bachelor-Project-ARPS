# =============================================================================
# Author: Deng MingXi
# Date: 2025.05.02
# Description: This script reads spectral data, applies Gaussian smoothing to the intensity values,
#              and then plots the smoothed data for different angles. Finally, it exports the smoothed data to a text file.
# =============================================================================

import pandas as pd
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter1d

# Read the data from the file
file_path = r"Code\curve51_calidata_0_to_80_symmetric_avg.txt"
data = pd.read_csv(file_path, sep="\t", comment="#", header=None, names=["angles (deg)", "Wavelengths", "intensity"])

# Apply Gaussian smoothing to the intensity data for each angle
sigma = 6  # Standard deviation for the Gaussian kernel; can be adjusted as needed
smoothed_data = []

# Iterate over each unique angle in the dataset
for angle in data["angles (deg)"].unique():
    angle_data = data[data["angles (deg)"] == angle]  # Extract data for the current angle
    smoothed_intensity = gaussian_filter1d(angle_data["intensity"].values, sigma=sigma)  # Apply Gaussian smoothing
    smoothed_data.append(pd.DataFrame({"angles (deg)": angle, "Wavelengths": angle_data["Wavelengths"], "Smoothed Intensity": smoothed_intensity}))

# Combine all smoothed data into a single DataFrame
smoothed_data = pd.concat(smoothed_data, ignore_index=True)

# Plot the smoothed data
plt.figure(figsize=(10, 6))

# Plot smoothed intensity vs. wavelength for each angle
for angle in smoothed_data["angles (deg)"].unique():
    angle_data = smoothed_data[smoothed_data["angles (deg)"] == angle]
    plt.plot(angle_data["Wavelengths"], angle_data["Smoothed Intensity"], label=f"Angle {angle:.0f} deg")

# Add title and labels to the plot
plt.title("Smoothed Intensity vs Wavelength for Different Angles")
plt.xlabel("Wavelengths (nm)")
plt.ylabel("Smoothed Intensity")
plt.legend()
plt.grid(True)

# Display the plot
plt.show()

# Export the smoothed data to a text file
output_file = r"Code\FittingDataInput51-0-80-cali-smoothed_data.txt"
smoothed_data.to_csv(output_file, sep="\t", index=False, float_format="%.10e", header=["# angles (deg)", "# Wavelengths", "# Smoothed Intensity"])

print(f"Smoothed data exported to {output_file}")