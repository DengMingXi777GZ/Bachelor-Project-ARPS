import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from glob import glob
import re
from scipy.interpolate import interp1d
from scipy.interpolate import griddata
# =============================================================================
# Author: Deng MingXi
# Date: 2025.05.02
# Description: This script processes spectral data, applies corrections, and generates heatmaps for different positions.
#              generates a data txt file for further analysis. 
# =============================================================================
# Parameters setup
data_folder = r'Experiment\Final-film429'  # Data folder path

# File patterns for different positions
pos1_pattern = os.path.join(data_folder, 'SuperYellow-P-2degree-3_ID2-2_Data1D*.txt')
pos2_pattern = os.path.join(data_folder, 'SuperYellow-P-2degree-3_ID2-2_Data1D*.txt')
pos3_pattern = os.path.join(data_folder, 'SuperYellow-P-2degree-3_ID2-2_Data1D*.txt')

# Get sorted file lists for each position
pos1_files = sorted(glob(pos1_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))
pos2_files = sorted(glob(pos2_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))
pos3_files = sorted(glob(pos3_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))

# Exclude the first 2 and last 1 files from each list (keep files from index 2 to -2)
pos1_files = pos1_files[2:-1] if len(pos1_files) > 3 else pos1_files
pos2_files = pos2_files[2:-1] if len(pos2_files) > 3 else pos2_files
pos3_files = pos3_files[2:-1] if len(pos3_files) > 3 else pos3_files

# Define the angles range
angles = np.arange(-80, 81, 2)
print("Correct angles:", angles)

# Initialize variables
wavelengths = None
pos1_matrix, pos2_matrix, pos3_matrix = [], [], []
filter_range = (470, 800)  # Wavelength range for filtering in nm

# Function to process spectral data files
def process_spectral_data(file_list):
    """
    Process spectral data files and return a matrix of intensities.
    """
    global wavelengths
    intensity_matrix = []
    for file in file_list:
        data = np.loadtxt(file, skiprows=3)  # Load data, skipping the first 3 rows
        wl = data[:, 0]  # Wavelengths
        intensity = data[:, 1]  # Intensities
        intensity[intensity < 0] = 0  # Set negative intensities to 0
        
        # Apply wavelength filter
        filter_mask = (wl <= filter_range[0]) | (wl >= filter_range[1])
        intensity[filter_mask] = 0
        if wavelengths is None:
            wavelengths = wl

        
        intensity_matrix.append(intensity)
    
    return np.array(intensity_matrix).T  # Transpose to match the desired shape

# Process data for each position
pos1_matrix = process_spectral_data(pos1_files)
pos2_matrix = process_spectral_data(pos2_files)
pos3_matrix = process_spectral_data(pos3_files)

# Load correction function data
correction_data = np.loadtxt(r'Code\correction_function1.txt', delimiter='\t')
correction_func = interp1d(correction_data[:, 0], correction_data[:, 1], bounds_error=False, fill_value=1.0)

# Apply correction function to spectral data
def correct_spectral_data(wl_array, data_matrix):
    """
    Apply correction factors to spectral data.
    """
    factors = correction_func(wl_array)
    return data_matrix * factors[:, np.newaxis]
print(wavelengths)
# Apply correction to each position's data
pos1_matrix = correct_spectral_data(wavelengths, pos1_matrix)
pos2_matrix = correct_spectral_data(wavelengths, pos2_matrix)
pos3_matrix = correct_spectral_data(wavelengths, pos3_matrix)

# Load time data
time_file = os.path.join(data_folder, 'SuperYellow-P-2degree-3_ID2-2.txt')
df_time = pd.read_csv(time_file, skiprows=5, delim_whitespace=True, header=None, parse_dates=[1])
df_time = df_time[:-1]  # Exclude the last row
timestamps = pd.to_datetime(df_time.iloc[:, 1])
time_seconds = (timestamps - timestamps[0]).dt.total_seconds().astype(float)
print("Time in seconds:", time_seconds)

# Load photobleaching curve data
bleaching_file = r'Photobleaching\bleaching_curve.xlsx'
df_bleaching = pd.read_excel(bleaching_file)
bleaching_time = df_bleaching.iloc[:, 0].values
bleaching_factor = df_bleaching.iloc[:, 2].values

# Interpolate photobleaching curve
bleaching_func = interp1d(bleaching_time, bleaching_factor, bounds_error=False, fill_value="extrapolate")

# Check for time values out of bounds
below_bounds = time_seconds < bleaching_time.min()
above_bounds = time_seconds > bleaching_time.max()
out_of_bounds_times = time_seconds[below_bounds | above_bounds]

if len(out_of_bounds_times) > 0:
    print("Time values out of bounds:", out_of_bounds_times)
    print("Indices of out-of-bounds times:", np.where(below_bounds | above_bounds))
else:
    print("All time values are within the bleaching time range.")

# Initialize correction factor array
correction_factor = np.zeros_like(time_seconds)
correction_factor[0] = 1.0  # Set the first correction factor to 1.0
correction_factor[1:] = bleaching_func(time_seconds[1:])  # Interpolate for other time points

# Add additional correction factor based on time
correction_factor += time_seconds * 0.008
print("Correction factor:", correction_factor)

# Ensure correction factor has the correct shape
correction_factor = np.tile(correction_factor, (len(wavelengths), 1))  # Shape: (len(wavelengths), len(time_seconds))
print("Correction factor shape:", correction_factor.shape)

# Apply photobleaching correction
pos1_matrix_o, pos2_matrix_o, pos3_matrix_o = pos1_matrix, pos2_matrix, pos3_matrix  # Save original data for comparison
pos1_matrix *= correction_factor
pos2_matrix *= correction_factor
pos3_matrix *= correction_factor

# Calculate total intensity for each position
pos1_total = np.sum(pos1_matrix, axis=0)
pos2_total = np.sum(pos2_matrix, axis=0)
pos3_total = np.sum(pos3_matrix, axis=0)

# Normalize intensities
pos1_norm_o = np.sum(pos1_matrix_o, axis=0) / np.sum(pos1_matrix_o, axis=0).max()
pos2_norm_o = np.sum(pos2_matrix_o, axis=0) / np.sum(pos2_matrix_o, axis=0).max()
pos3_norm_o = np.sum(pos3_matrix_o, axis=0) / np.sum(pos3_matrix_o, axis=0).max()
pos1_norm = pos1_total / pos1_total.max()
pos2_norm = pos2_total / pos2_total.max()
pos3_norm = pos3_total / pos3_total.max()

# Normalize heatmap data
pos1_matrix = pos1_matrix / pos1_matrix.max()
pos2_matrix = pos2_matrix / pos2_matrix.max()
pos3_matrix = pos3_matrix / pos3_matrix.max()
# Create a grid for the heatmap
fig, axes = plt.subplots(3, 2, figsize=(18, 12), gridspec_kw={'height_ratios': [3, 3, 3], 'hspace': 0.4, 'wspace': 0.3})

# Create a grid for interpolation
# Define a 500x500 grid within the range of angles and wavelengths for interpolation
grid_x, grid_y = np.mgrid[angles.min():angles.max():100j, wavelengths.min():wavelengths.max():100j]

# Create points for interpolation
# Generate the coordinates of all points to be interpolated
points = np.vstack((angles.repeat(len(wavelengths)), np.tile(wavelengths, len(angles)))).T  # Create scatter coordinates
values = pos1_matrix.T.flatten()  # Flatten the original data
grid_z1 = griddata(points, values, (grid_x, grid_y), method='cubic')  # Perform interpolation
# Plot the heatmap for Position1
im1 = axes[0, 0].imshow(grid_z1.T, extent=[angles.min(), angles.max(), wavelengths.min(), wavelengths.max()], origin='lower', cmap='plasma', aspect='auto', vmin=0, vmax=1)
axes[0, 0].set_ylabel('Wavelength (nm)')
axes[0, 0].set_xlabel('Angle (degrees)')
# Set the range of the y-axis
axes[0, 0].set_ylim(400, 800)
axes[0, 0].set_title('Position1 (Filtered {}-{}nm)'.format(*filter_range))
fig.colorbar(im1, ax=axes[0, 0], label='Normalized Intensity')

# Position2 heatmap
values = pos2_matrix.T.flatten()  # Flatten the original data
grid_z2 = griddata(points, values, (grid_x, grid_y), method='cubic')  # Perform interpolation
im2 = axes[1, 0].imshow(grid_z2.T, extent=[angles.min(), angles.max(), wavelengths.min(), wavelengths.max()], origin='lower', cmap='plasma', aspect='auto', vmin=0, vmax=1)
axes[1, 0].set_ylabel('Wavelength (nm)')
axes[1, 0].set_xlabel('Angle (degrees)')
# Set the range of the y-axis
axes[1, 0].set_ylim(400, 800)
axes[1, 0].set_title('Position2 (Filtered {}-{}nm)'.format(*filter_range))
fig.colorbar(im2, ax=axes[1, 0], label='Normalized Intensity')

# Position3 heatmap
values = pos3_matrix.T.flatten()  # Flatten the original data
grid_z3 = griddata(points, values, (grid_x, grid_y), method='cubic')  # Perform interpolation
im3 = axes[2, 0].imshow(grid_z3.T, extent=[angles.min(), angles.max(), wavelengths.min(), wavelengths.max()], origin='lower', cmap='plasma', aspect='auto', vmin=0, vmax=1)
axes[2, 0].set_ylabel('Wavelength (nm)')
axes[2, 0].set_xlabel('Angle (degrees)')
# Set the range of the y-axis
axes[2, 0].set_ylim(400, 800)
axes[2, 0].set_title('Position3 (Filtered {}-{}nm)'.format(*filter_range))
fig.colorbar(im3, ax=axes[2, 0], label='Normalized Intensity')

# Combine the subplots in the second column for a comparison plot
# Remove the original subplots in the second column
gs = axes[0, 1].get_gridspec()
for ax in [axes[0, 1], axes[1, 1], axes[2, 1]]:
    ax.remove()
# Create a new subplot spanning all rows in the second column
ax_bottom = fig.add_subplot(gs[:, 1])  

# Comparison plot
# Plot the normalized intensity curves for each position before and after correction
ax_bottom.plot(angles, pos1_norm_o, label='Position1 Before Correction', marker='o', color='red')
ax_bottom.plot(angles, pos2_norm_o, label='Position2 Before Correction', marker='s', color='orange')
ax_bottom.plot(angles, pos3_norm_o, label='Position3 Before Correction', marker='^', color='green')
ax_bottom.plot(angles, pos1_norm, label='Position1 After Correction', marker='o', color='crimson')
ax_bottom.plot(angles, pos2_norm, label='Position2 After Correction', marker='s', color='royalblue')
ax_bottom.plot(angles, pos3_norm, label='Position3 After Correction', marker='^', color='limegreen')
ax_bottom.set_xlabel('Angle (degrees)')
ax_bottom.set_ylabel('Normalized Intensity')
ax_bottom.set_title('SuperYellow-Ion-P')
ax_bottom.legend()
ax_bottom.grid(True)
ax_bottom.set_ylim(0, 1.05)

plt.tight_layout()
plt.show()

# Extract intensity data for the first angle
import numpy as np

# Get all negative angles (-80 to -2 degrees)
negative_angles = [a for a in angles if a < 0]
positive_angles = np.unique(np.abs(negative_angles))  # Corresponding positive angles [2,4,...,80]

# Average the intensity data for each pair of symmetrical angles
for pos_angle in positive_angles:
    neg_angle = -pos_angle
    # Get the indices corresponding to the angles
    neg_idx = np.where(angles == neg_angle)[0][0]
    pos_idx = np.where(angles == pos_angle)[0][0]
    
    # Calculate the average intensity and assign it to the positive angle
    avg_intensity = (pos1_matrix[:, neg_idx] + pos1_matrix[:, pos_idx]) / 2
    pos1_matrix[:, pos_idx] = avg_intensity

# Extract data for angles from 0 to 80 degrees
start_index = np.where(angles == 0)[0][0]
end_index = np.where(angles == 80)[0][0]
selected_angles = angles[start_index:end_index + 1]  # Angles from 0 to 80 degrees
selected_intensity = pos1_matrix[:, start_index:end_index + 1]

# Create an array for exporting the data
export_data = []
for i, angle in enumerate(selected_angles):
    angle_data = np.column_stack((np.full_like(wavelengths, angle),
                                wavelengths,
                                selected_intensity[:, i]))
    export_data.append(angle_data)

export_data = np.vstack(export_data)

# Save the data to a txt file
# output_file = r"Code\curve51_calidata_0_to_80_symmetric_avg.txt"
# header = "# Angle (deg)\t# Wavelength (nm)\t# Intensity"
# np.savetxt(output_file, export_data,
#            fmt=["%.2f", "%.2f", "%.10e"],
#            delimiter="\t",
#            header=header,
#            comments="")  # Remove the '#' at the beginning of the header
# print(f"Data exported to {output_file}")