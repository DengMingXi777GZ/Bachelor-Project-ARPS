import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d


file1 = pd.read_excel(r'mingxi\200-950 UV 19ms 100times.xlsx') 
#file1 = pd.read_excel(r'mingxi\400-1100 NIR 19ms 100times.xlsx') 
file3 = pd.read_excel(r'mingxi\mingxi-200ms 20times.xlsx')  
x1, y1 = file1.iloc[:, 0].values, file1.iloc[:, 1].values
x3, y3 = file3.iloc[:, 0].values, file3.iloc[:, 1].values
#-----------------------------------------------------------#
# 计算校正函数 (y1/y3)
y3_interp = np.interp(x1, x3, y3)  # 将Data3插值到Data1的波长网格上
# x<200或x>800时设为1
correction_factor = np.where((x1 < 200) | (x1 > 800), 1.0, y1 / y3_interp)
# 创建校正函数对象 (便于后续使用)
correction_func = interp1d(x1, correction_factor, 
                          kind='linear', 
                          bounds_error=False, 
                          fill_value=1.0)  # 超出范围设为1
#-----------------------------------------------------------#
# 可视化校正函数
plt.figure(figsize=(8, 9))
plt.subplot(3, 1, 1)
plt.plot(x1, y1, label='200-950nm UV', color='blue')
plt.plot(x3, y3, label='White Light', color='orange')
plt.legend(loc='upper right')
plt.xlabel('Wavelength (nm)')
plt.ylabel('Intensity')
plt.title('Spectral Data')
plt.grid(True)

plt.subplot(3, 1, 2)
plt.plot(x1, correction_factor, label='Correction Factor (y1/y3)', color='green')
plt.axvline(x=200, color='r', linestyle='--', label='Cutoff at 200nm')
plt.axvline(x=800, color='r', linestyle='--', label='Cutoff at 800nm')
plt.legend(loc='upper right')
plt.title('Correction Factor Function')
plt.xlabel('Wavelength (nm)')
plt.ylabel('Correction Factor')
plt.grid(True)

#-----------------------------------------------------------#
#载入待纠正样本txt
file_sample=np.loadtxt(r'Final-film\SuperYellow-P-5degree-3_ID2-2_Data1D_25.txt', skiprows=3)
wl_sample = file_sample[:, 0]
intensity_sample = file_sample[:, 1]
filter_range = (380, 450)  # nm
# 进行滤波
filter_mask = (wl_sample >= filter_range[0]) & (wl_sample <= filter_range[1])
intensity_sample[filter_mask] = 0
# 将负值设为0
intensity_sample[intensity_sample < 0] = 0

#-----------------------------------------------------------#
# 进行校正
corrected_intensity = intensity_sample * correction_func(wl_sample)

#归一化
intensity_sample /= np.max(intensity_sample)
corrected_intensity /= np.max(corrected_intensity)


plt.subplot(3, 1, 3)
plt.plot(wl_sample, intensity_sample, label='Original Sample', color='blue')
plt.plot(wl_sample, corrected_intensity, label='Corrected Sample', color='orange')
plt.legend(loc='upper right')
plt.xlabel('Wavelength (nm)')
plt.ylabel('Intensity')
plt.title('Corrected Sample Spectrum')
plt.grid(True)
plt.tight_layout()
plt.show()









