import os
import numpy as np
import matplotlib.pyplot as plt
from glob import glob
import re

data_folder = 'Final413' 
p_pattern = os.path.join(data_folder, 'SuperYellow-P_ID2-2_Data1D_*.txt')
background_pattern = os.path.join(data_folder, 'SuperYellow-Background_ID2-2_Data1D_*.txt')

p_files = sorted(glob(p_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))
bg_files = sorted(glob(background_pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))


def extract_angle(filename):
    match = re.search(r'_(\d+)\.txt$', os.path.basename(filename))
    return int(match.group(1)) if match else -1

angles = [extract_angle(f) for f in p_files]
print("Angles:", angles)

wavelengths = None
p_matrix = []
p_bg_subtracted_matrix = []  # 存储扣除背景后的P光数据

# 定义滤波范围
filter_range = (390, 420)  # nm

for p_file, bg_file in zip(p_files, bg_files):
    p_data = np.loadtxt(p_file, skiprows=3)
    bg_data = np.loadtxt(bg_file, skiprows=3)
    
    wl = p_data[:, 0]
    p_intensity = p_data[:, 1]
    bg_intensity = bg_data[:, 1]

    p_intensity[p_intensity < 0] = 0
    bg_intensity[bg_intensity < 0] = 0

    # 过滤指定波段
    filter_mask = (wl >= filter_range[0]) & (wl <= filter_range[1])
    p_intensity[filter_mask] = 0
    bg_intensity[filter_mask] = 0

    if wavelengths is None:
        wavelengths = wl

    # 背景插值以保证波长一致
    bg_interp = np.interp(wavelengths, wl, bg_intensity)
    
    bg_corrected = p_intensity - bg_interp
    bg_corrected[bg_corrected < 0] = 0

    p_matrix.append(p_intensity)
    p_bg_subtracted_matrix.append(bg_corrected)

p_matrix = np.array(p_matrix).T
p_bg_subtracted_matrix = np.array(p_bg_subtracted_matrix).T

# 归一化处理
p_total = np.sum(p_matrix, axis=0)
p_bg_subtracted_total = np.sum(p_bg_subtracted_matrix, axis=0)
max_total = max(p_total.max(), p_bg_subtracted_total.max())

p_norm = p_total / max_total
p_bg_subtracted_norm = p_bg_subtracted_total / max_total

fig, axes = plt.subplots(2, 2, figsize=(12, 10), gridspec_kw={'height_ratios': [3, 2], 'width_ratios': [1, 1],'hspace': 0.4, 'wspace': 0.3})


gs = axes[1, 0].get_gridspec()
for ax in axes[1, :]:
    ax.remove()  
ax_bottom = fig.add_subplot(gs[1, :])  # 创建一个横跨两列的新子图

extent = [min(angles), max(angles), wavelengths[0], wavelengths[-1]]


im1 = axes[0, 0].imshow(p_matrix, aspect='auto', cmap='viridis', extent=extent, origin='lower')
axes[0, 0].set_ylabel('Wavelength (nm)')
axes[0, 0].set_title(f'P-Polarized Raw (Filtered {filter_range[0]}-{filter_range[1]}nm)')
fig.colorbar(im1, ax=axes[0, 0], label='Intensity')


im2 = axes[0, 1].imshow(p_bg_subtracted_matrix, aspect='auto', cmap='plasma', extent=extent, origin='lower')
axes[0, 1].set_ylabel('Wavelength (nm)')
axes[0, 1].set_title(f'P-Polarized BG Subtracted (Filtered {filter_range[0]}-{filter_range[1]}nm)')
fig.colorbar(im2, ax=axes[0, 1], label='Intensity')

ax_bottom.plot(angles, p_norm, label='P-Polarized Raw', marker='o', color='crimson')
ax_bottom.plot(angles, p_bg_subtracted_norm, label='P-Polarized BG Subtracted', marker='s', color='royalblue')
ax_bottom.set_xlabel('Angle (degrees)')
ax_bottom.set_ylabel('Normalized Total Intensity')
ax_bottom.set_ylim(0, 1.05)
ax_bottom.grid(True)
ax_bottom.legend()

plt.tight_layout()
plt.show()