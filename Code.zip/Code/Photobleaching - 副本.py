import os
import numpy as np
import pandas as pd
from glob import glob
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import re

# 参数设置
data_folder = 'Photobleaching'
filter_range = (390, 430)  # 滤波范围(nm)
skip_first_files = 3       # 跳过前几个文件

# 1. 加载时间数据
time_file = os.path.join(data_folder, 'SuperYellow-P_ID1-1.txt')
df = pd.read_csv(time_file, skiprows=3, delim_whitespace=True, 
                header=None, parse_dates=[1])
timestamps = pd.to_datetime(df.iloc[:, 1])
time_seconds = (timestamps - timestamps[0]).dt.total_seconds().astype(float)

# 2. 加载光谱数据并计算总光强
def load_and_process_spectra(pattern):
    files = sorted(glob(pattern), key=lambda f: int(re.search(r'_(\d+)\.txt$', f).group(1)))
    files = files[skip_first_files:] if len(files) > skip_first_files else files
    
    total_intensities = []
    for file in files:
        data = np.loadtxt(file, skiprows=3)
        wl, intensity = data[:, 0], data[:, 1]
        intensity[(intensity < 0) | ((wl >= filter_range[0]) & (wl <= filter_range[1]))] = 0
        total_intensities.append(np.trapz(intensity, wl))
    return np.array(total_intensities)

total_intensity = load_and_process_spectra(os.path.join(data_folder, 'SuperYellow-P_ID1-1_Data1D_*.txt'))
normalized_intensity = total_intensity / total_intensity[0]

def moving_average(data, window_size):
    return np.convolve(data, np.ones(window_size) / window_size, mode='valid')  # convolve函数计算滑动平均值,步长为1

# 平滑数据
window_size = 5  # 平滑窗口大小
smoothed_intensity = moving_average(normalized_intensity, window_size)
smoothed_time = time_seconds[:len(smoothed_intensity)]  # 确保时间数组与强度数组对齐

# 指数衰减函数，添加约束条件 y(0)=1
def exp_decay_constrained(t, a, tau):
    return a * np.exp(-t/tau) + (1 - a)

# 初始猜测参数 [初始振幅, 衰减时间常数]
p0 = [1.0, 20]

# 拟合指数衰减模型
popt_smoothed, pcov_smoothed = curve_fit(exp_decay_constrained, smoothed_time, smoothed_intensity, p0=p0)
fit_curve_smoothed = exp_decay_constrained(smoothed_time, *popt_smoothed)

# 绘制图形
plt.figure(figsize=(10, 6), dpi=100)

# 原始数据（半透明显示）
plt.scatter(time_seconds, normalized_intensity, alpha=0.3, color='blue', label='Raw data')

# 平滑后的数据
plt.scatter(smoothed_time, smoothed_intensity, alpha=0.6, color='green', label='Smoothed data')

# 拟合曲线（突出显示）
plt.plot(smoothed_time, fit_curve_smoothed, 'r-', linewidth=2.5, label=f'Exponential fit: y={popt_smoothed[0]:.2f}e^(-t/{popt_smoothed[1]:.1f})+(1-{popt_smoothed[0]:.2f})')

# 标注关键参数
r_squared = 1 - np.var(smoothed_intensity - fit_curve_smoothed) / np.var(smoothed_intensity)
plt.text(0.6, 0.8, 
         f"τ = {popt_smoothed[1]:.1f} s\nR² = {r_squared:.3f}",
         transform=plt.gca().transAxes, bbox=dict(facecolor='white', alpha=0.8))

plt.xlabel('Time (seconds)', fontsize=12)
plt.ylabel('Normalized Intensity (I/I₀)', fontsize=12)
plt.title('Photobleaching Decay with Exponential Fit (Smoothed Data)', fontsize=14)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend(fontsize=10)
plt.tight_layout()
plt.show()

# 创建DataFrame并保存为Excel文件
# df_data = pd.DataFrame({
#     'Time (seconds)': smoothed_time,
#     'Intensity': smoothed_intensity
# })
#df_data.to_excel('photobleaching_data.xlsx', index=False)